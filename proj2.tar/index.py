# Berkeley DB Example

__author__ = "Bing Xu"
__email__ = "bx3@ualberta.ca"

import bsddb
import time
import sys
import os
from ctypes import cdll
lib = cdll.LoadLibrary('./libfoo.so')


DA_FILE_K = "/tmp/rleung_db3"
DA_FILE_D = "/tmp/rleung_db4"
DB_SIZE = 100000
SEED = 10000000


def destroy():
    os.remove(DA_FILE_K)
    os.remove(DA_FILE_D)
    print "Files deleted"

    
def writing(key, data):
    File = open('answers', 'a')
    File.write(key)
    File.write('\n')
    File.write(data)
    File.write('\n')
    File.write('\n')
    File.close()

def retrieve_key(db):
    key = '-1'
    while int(key) not in xrange(0, DB_SIZE):
        try:
            key = str(int(input("Please enter a valid key:  \n")))
        except:
            print "invalid input"

    try:
        if db.has_key(key):
            writing(key, db[key])
            return db[key]
    except:
        print "NO DATA FOUND"
    return False

def retrieve_data(db):
    test = " "*62
    invalid = True
    while invalid and len(test) not in xrange(64,128):
            try:
                test = str(raw_input("Please enter data, must be between 64 and 127 characters:  \n"))
                if len(test) not in xrange(64, 128):
                    raise Exception
                if test == 'q':
                    return False
                invalid = False
            except:
                print "invalid input"    
    try:
        if db.has_key(test):
            keys = db[test].split()
            for key in keys:
                writing(key, test)
            return db[test]
        else:
            print "NO DATA FOUND"
            return False            
    except:
        print "NO DATA FOUND"
        return False


def retrieve_key_range(db):
    key1 = '-1'
    while int(key1) not in xrange(0, DB_SIZE):
        try:
            key1 = str(int(input("Please enter a valid starting key:  \n")))
        except:
            print "invalid input"   
            
    key2 = '-1'
    invalid = True
    while int(key2) not in xrange(0, DB_SIZE) or invalid== True:
        try:
            key2 = str(int(input("Please enter a valid ending key:  \n")))
            if int(key2)<=int(key1):
                print "the ending key must be more than the first"
            else:
                invalid = False
        except:
            print "invalid input"
            
    found = []        
    for i in range(int(key1), int(key2)):
        if db.has_key(str(i)):
            writing(str(i),db[str(i)]) 
            found.append(db[str(i)])
    return found








def main():
    try:
        db_key = bsddb.hashopen(DA_FILE_K, "w")
    except:
        print "DB doesn't exist, creating a new one"
        try:
            db_key = bsddb.hashopen(DA_FILE_K, "c")
        except:
            print "the database was not created."
            return
    try:
        db_data = bsddb.hashopen(DA_FILE_D, "w")
    except:
        print "DB doesn't exist, creating a new one"
        try:
            db_data = bsddb.hashopen(DA_FILE_D, "c")
        except:
            print "the database was not created."
            return    
    lib.set_seed(SEED)

    for index in range( DB_SIZE):
        krng = 64 + lib.get_random() % 64
        key = str(index)
        vrng = 64 + lib.get_random() % 64
        value = ""
        ck = key
        for i in range(vrng):
            value += str(unichr(lib.get_random_char()))
        db_key[key] = value
    
    for index in xrange(DB_SIZE-1):
        key = str(index)
        keys = key
        data = db_key[key]
        if db_data.has_key(data):
            db_data[data] = db_data[data]+" "+keys
        else:
            db_data[data] = keys
            
        
    return (db_key, db_data)    
if __name__ == "__main__":
    main()
   
