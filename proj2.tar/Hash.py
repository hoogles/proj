
import bsddb
import time
import sys
import os
from ctypes import cdll
lib = cdll.LoadLibrary('./libfoo.so')


DA_FILE = "/tmp/rleung_db2"
DB_SIZE = 100000
SEED = 10000000

def destroy():
    os.remove(DA_FILE)
    print "File deleted"
    
def writing(key, data):
    File = open('answers', 'a')
    File.write(key)
    File.write('\n')
    File.write(data)
    File.write('\n')
    File.write('\n')
    File.close()
    
def retrieve_key(db):
    key = '-1'
    while int(key) not in xrange(0, DB_SIZE):
        try:
            key = str(int(input("Please enter a valid key:  \n")))
        except:
            print "invalid input"

    try:
        if db.has_key(key):
            writing(key, db[key])
            return db[key]
    except:
        print "NO DATA FOUND"
    return False

def retrieve_data(db):
    test = " "*62
    invalid = True
    while invalid and len(test) not in xrange(64,128):
            try:
                test = str(raw_input("Please enter data, must be between 64 and 127 characters:  \n"))
                if len(test) not in xrange(64, 128):
                    raise Exception
                if test == 'q':
                    return False
                invalid = False
            except:
                print "invalid input"    
    x= db.first()[1]
    i =0
    found = 0
    while x!= test:   
        x = db.next()
        i+=1
        if test== x[1]:
            writing(x[0], x[1])
            found += 1
        if i>= DB_SIZE-2:
            break
        
    if found ==0:
        print "NO DATA FOUND"
        return False
    print "FOUND"
    return True


def retrieve_key_range(db):
    key1 = '-1'
    while int(key1) not in xrange(0, DB_SIZE):
        try:
            key1 = str(int(input("Please enter a valid starting key:  \n")))
        except:
            print "invalid input"   
            
    key2 = '-1'
    invalid = True
    while int(key2) not in xrange(0, DB_SIZE) or invalid== True:
        try:
            key2 = str(int(input("Please enter a valid ending key:  \n")))
            if int(key2)<=int(key1):
                print "the ending key must be more than the first"
            else:
                invalid = False
        except:
            print "invalid input"
            
    found = []        
    for i in range(int(key1), int(key2)):
        if db.has_key(str(i)):
            found.append(db[str(i)])
    return found
    
def main():
    try:
        db = bsddb.hashopen(DA_FILE, "w")
    except:
        print "DB doesn't exist, creating a new one"
        db = bsddb.hashopen(DA_FILE, "c")
    lib.set_seed(SEED)

    for index in range(1, DB_SIZE):
        krng = 64 + lib.get_random() % 64
        key = str(index)
        vrng = 64 + lib.get_random() % 64
        value = ""
        ck = key
        for i in range(vrng):
            value += str(unichr(lib.get_random_char()))
        db[key] = value
        
    return db

if __name__ == "__main__":
    main()
