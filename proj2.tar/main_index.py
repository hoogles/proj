


import bsddb 
from ctypes import cdll
lib = cdll.LoadLibrary('./libfoo.so')

from index import *

'''1 Create and populate the database <-I feel this should be automatic

2 Retrieve records with a given key

3 Retrieve records with a given data

4. Retrieve records with a given range of key values

5. Destroy the database

6. Quit'''

print("The following commands an their numbers")
print("1. Create and populate the database")
print("2. Retrieve records with a given key")
print("3. Retrieve records with a given data")
print("4. Retrieve records with a given range of key values")
print("5. Destroy the database")
print("6. Quit")
entry = 0
populated = False
db_key = None
db_data = None
while entry!= 6:
    try:
        entry = int(str(raw_input("Select an option: ")))    
        if entry == 1 and not populated:
            print "please wait ..."            
            db_key, db_data = main() 
            if db_key != None and db_data!= None:
                print "database created"
                populated = True
                
        elif entry == 2 and populated:
            time1 = time.time()*1000 
            data = retrieve_key(db_key)
            time3 = time.time()*1000 - time1
            if data != False:
                print "1 records found"
            else:
                print "NO DATA FOUND"
            print "Execution time:", time3
    
        elif entry == 3 and populated:
            time1 = time.time()*1000
            keys = retrieve_data(db_data)
            time3 = time.time()*1000 - time1
            if keys != False:
                print len(keys), "records found"
            print "Execution time:", time3
            
        elif entry == 4 and populated:
            time1 = time.time()*1000
            found = retrieve_key_range(db_key)
            time3 = time.time()*1000 - time1
            print len(found), "records found"
            print "Execution time:", time3
            
        elif entry == 5 and populated:
            db_key.close()
            db_data.close()
            destroy()
            db = None
            populated = False
            
        elif entry == 6 and populated:
            db_key.close()
            db_data.close()
            destroy()
            db = None
            populated = False
            
    except:
        print "invalid input"