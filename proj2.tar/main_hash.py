


import bsddb
from ctypes import cdll
lib = cdll.LoadLibrary('./libfoo.so')
from Hash import *

'''1 Create and populate the database <-I feel this should be automatic

2 Retrieve records with a given key

3 Retrieve records with a given data

4. Retrieve records with a given range of key values

5. Destroy the database

6. Quit'''

print("The following commands an their numbers")
print("1. Create and populate the database")
print("2. Retrieve records with a given key")
print("3. Retrieve records with a given data")
print("4. Retrieve records with a given range of key values")
print("5. Destroy the database")
print("6. Quit")
entry = 0
populated = False
db = None
while entry!= 6:
    try:
        entry = int(str(raw_input("Select an option: ")))    
        if entry == 1 and not populated:
            print "please wait ..."
            db = main()
            if db != None:
                print "database created"
                populated = True
        elif entry == 2 and populated:
            time1 = time.time()*1000
            data = retrieve_key(db)
            time3 = time.time()*1000 - time1
            if data != False:
                print "1 records found"            
            print "time to execute: ", time3
        elif entry == 3 and populated:
            time1 = time.time()*1000
            retrieve_data(db)
            time3 = time.time()*1000 - time1
            print "time to execute: ", time3
        elif entry == 4 and populated:
            time1 = time.time()*1000        
            found =  retrieve_key_range(db)
            time3 = time.time()*1000 - time1
            print len(found), "records found"
            print "time to execute: ", time3
        elif entry == 5 and populated:
            db.close()
            destroy()
            db = None
            populated = False
        elif entry == 6 and populated:
            db.close()
            destroy()
            db = None
            populated = False
            
            
    except:
        print "invalid input"
            